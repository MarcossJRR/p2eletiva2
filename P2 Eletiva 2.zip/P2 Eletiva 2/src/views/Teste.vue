<template>
  <div>
    <h1>TESTE</h1>
  </div>
</template>

<script>
export default {
    name: 'Teste'
}
</script>

<style>
</style>
