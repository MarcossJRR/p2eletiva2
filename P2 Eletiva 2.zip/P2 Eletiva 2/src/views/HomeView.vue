<script setup>
</script>

<template>
  <main>
    <div class="title-principal">Rick and Morty</div>
    <div class="logo-principal">
      <img class="logo" src="./rick.jpeg">
    </div>
    <div class="container_input">
      <input type="search" v-model="input_busca" placeholder="Insira o personagem">
      <input type="button" value="Buscar" @click="buscar()">
    </div>
    <div v-if="itens_response && itens_response.length < 1 && buscou">
      <p v-if="erro_api">Não foi possível acessar a API!</p>
      <p v-else>Nenhum registro encontrado!</p>
    </div>
    <div v-else>
      <div v-if="Array.isArray(itens_response)" class="principal">
        <div class="container_info"  v-for="(item, index) in itens_response" :key="index">
          <img :src="item.image ? item.image : ''">
          <p>{{ item.name ? item.name : '' }}</p>
        </div>
      </div>
      <div v-else>
        <img :src="itens_response.image ? itens_response.image : ''">
        <p>{{ itens_response.name ? itens_response.name : '' }}</p>
      </div>
    </div>
  </main>
</template>

<script>
import api from '../services/api'
export default {
    name: 'Menu',
    components: { api },
    data () {
      return {
        input_busca: '',
        itens_response: [],
        buscou: false,
        erro_api: false
      }
    },
    methods: {
      buscar () { 
        api.get(`?page=${this.input_busca}`).then(res => {
          this.buscou = true   
          this.itens_response = res.data.data
        }).catch(() => {
          this.erro_api = true
          this.buscou = true            
        }).finally(() => {
          setTimeout(() => {
            this.buscou = false
          }, 3000);
        })     
      }
    }
}
</script>

<style scoped>
  .container_input {
    margin-top: 20px;
    justify-content: center;
    display: flex;
  }

  .container_info {
      margin-top: 20px;
      padding: 5px;
  }

  .principal{
      display: flex;
      margin: 5px;
      flex-wrap: wrap;
      background-color: black;
  }

  .title-principal{
    margin-top: 20px;
    justify-content: center;
    display: flex;
    font-size: larger;
    font-weight: 600;
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
  }

  .logo{
      height: 300px;
  }

  .logo-principal{
    justify-items: center;
    align-items: center;
    display: flex;
    margin-left: 30rem;
  }
</style>