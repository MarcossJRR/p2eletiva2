<template>
  <div>
    <h1>ABOUT </h1>
  </div>
</template>

<style>
</style>
